# This script assumes that you have not changed anything about the WEPPCLIFF.zip
# folder structure after unzipping it. If you have changed it, please download
# the folder again before running this script.

# Set directories.
cw.dir <<- getwd()
setwd('././')
home.dir <<- getwd()
setwd('LIBRARY')
lib.dir <<- getwd()

# List packages.
package.list = c("readr", "rlist", "doParallel", "hashmap", "EnvStats", "mice",
                 "RcppParallel", "LambertW", "ggplot2", "profvis", "crayon", "data.table")

# Try this first.
lapply(package.list, install.packages, lib = lib.dir, type = 'binary', repos = 'http://cran.us.r-project.org')

# Try this if the first try does not succeed.
lapply(package.list, install.packages, lib = lib.dir, type = 'source', repos = 'http://cran.us.r-project.org')

# If neither of these work, ask someone who knows R and the CRAN network well to help you.
# The WEPPCLIFF team assists with WEPPCLIFF issues only, not the configuration of R on unique machines.