Author: Ryan McGehee
Created: 21 November 2019
Purpose: Describe contents of the folder 'TUTORIAL'


Content:

Tutorial.txt				A tutorial document with comments that provides:
						--important information about the tutorial
						--example commands to demonstrate WEPPCLIFF capabilities
						--an introduction to different precipitation data types

AutoTutorial.sh				A shell script to run the tutorial automatically on a UNIX system

AutoTutorial.bat			A batch script to run the tutorial automatically on a Windows system

README.txt				This document
