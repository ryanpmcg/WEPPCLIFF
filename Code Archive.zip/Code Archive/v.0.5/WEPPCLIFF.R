#  Last Updated by: Ryan P. McGehee
#  Last Updated on: 3 October 2018
#  Purpose: This program is designed to create an appropriate WEPP input
#           climate file (.cli) from acceptable inputs. The following 
#           functionality is supported by the program (and more):
#
#           1) accepts arguments in any order
#           2) provides feedback on inappropriate arguments
#           3) accepts CSV or TSV input formats (as .csv or .txt, respectively)
#           4) accepts columns or 'variables' in any order
#           5) halts execution if insufficient data provided
#           6) trims data to specified time parameters
#           7) enables multiple station batch processing
#           8) enables parallel processing of multiple stations
#           9) enables event-based processing of multiple stations
#          10) accepts cumulative or incremental precipitation data
#          11) accepts fixed-interval or fixed-intensity precipitation data
#          12) parses user specified date and datetime formats
#          13) accepts english or metric unit inputs (by variable)
#          14) handles timezone differences by station
#          15) calculates kinetic energy, intensity, and erosivity
#          16) graphs time series of each variable by station
#          17) performs basic data quality checks
#          18) replaces missing or bad data
#          19) optimizes parallel processing architecture
#          20) reports computation time by station
#          21) allows forced single core operation
#          22) supports cluster environment processing
#
#  License:

#############################################################################
#
#   WEPP Climate File Formatter (WEPPCLIFF)
#   Copyright (C) Ryan P. McGehee
#
#   This is free software protected under the terms of the GNU General Public
#   License (GPL) as published by the Free Software Foundation (i.e. a free
#   and open source software (FOSS) license).
#
#   Under this license YOU CAN FREELY:
#         Execute, study, copy, modify, or distribute the software or any
#         derivatives thereof ONLY UNDER THE CONDITIONS OF THIS LICENSE
#         (i.e. under this FOSS license).
#
#   Under this license YOU CANNOT:
#         Sell THIS SOFTWARE OR ANY DERIVATIVES (i.e. your own modifications)
#         thereof without the explicit permission of the author/developer.
#
#   If you do use, test, or distribute this software, please provide an
#   appropriate citation in published work as follows:
#
#   McGehee, R.P. 2018. WEPP Climate File Formatter (WEPPCLIFF). Avail. at:
#         ###GITHUB### doi: (NOT YET ASSIGNED)
#
#   Corresponding Author: R.P. McGehee
#   E-mail: ryanpmcgehee@gmail.com
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#   GNU GPL for more details.
#
#############################################################################


# A function to print a license agreement and accept user response.
prompt_license_agreement = function(){
  LICENSE = {"
  ###############################################################################
    #
    #   WEPP Climate File Formatter (WEPPCLIFF)
    #   Copyright (C) Ryan P. McGehee
    #
    #   This is free software protected under the terms of the GNU General Public
    #   License (GPL) as published by the Free Software Foundation (i.e. a free
    #   and open source software (FOSS) license).
    #
    #   Under this license YOU CAN FREELY:
    #         Execute, study, copy, modify, or distribute the software or any
    #         derivatives thereof ONLY UNDER THE CONDITIONS OF THIS LICENSE
    #         (i.e. under this FOSS license).
    #
    #   Under this license YOU CANNOT:
    #         Sell THIS SOFTWARE OR ANY DERIVATIVES (i.e. your own modifications)
    #         thereof without the explicit permission of the author/developer.
    #
    #   If you do use, test, or distribute this software, please provide an
    #   appropriate citation in published work as follows:
    #
    #   McGehee, R.P. 2018. WEPP Climate File Formatter (WEPPCLIFF). Available at:
    #         ###GITHUB### doi: (NOT YET ASSIGNED)
    #
    #   Corresponding Author: R.P. McGehee
    #   E-mail: ryanpmcgehee@gmail.com
    #
    #   This program is distributed in the hope that it will be useful,
    #   but WITHOUT ANY WARRANTY; without even the implied warranty of
    #   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    #   GNU GPL for more details.
    #
    ###############################################################################
    "}
  
  cat(rep(lr, 30))
  cat(LICENSE)
  cat(lr, lr, "Do you accept these conditions? (Y/N)", lr, lr, collapse = '')
  stdin = file("stdin")
  response = readLines(stdin, n = 1L)
  close(stdin)
  if (toupper(response) != 'Y'){
    stop("You must acknowledge your agreement to the license conditions with 'Y' to use this software.")}}


# A function to determine directory location.
set_wds = function(){
  home.dir <<- getwd()
  setwd('LIBRARY')
  lib.dir <<- getwd()
  setwd(home.dir)
  setwd('INPUT')
  in.dir <<- getwd()
  setwd(home.dir)
  setwd('OUTPUT')
  out.dir <<- getwd()
  setwd(home.dir)
  setwd('EXPORT')
  ex.dir <<- getwd()
  setwd(home.dir)
  setwd('PLOTS')
  plot.dir <<- getwd()
  setwd(home.dir)}


# A function to install R package dependencies on the first run.
install_dependencies = function(){
  cat('Installing R package dependencies...', lr, lr, sep = '')
  lapply(package.list, install.packages, lib = lib.dir, type = 'binary', repos = 'http://cran.us.r-project.org')
  cat(lr, lr, 'Done.', lr, lr, sep = '')}


# A function to locate acceptable arguments.
parse_arg_locations = function(){
  for (i in flags){
    x = which(args == paste('-', i, sep = ''))
    assign(paste(i, '.loc', sep = ''), x, envir = .GlobalEnv)}}


# A function to assign arguments to global variables.
assign_args_to_vars = function(){
  cat(rep(lr, 30))
  cat(paste("User Specified Arguments: ", length(grep('-', args)) - 1, " of ", length(flags), " possible arguments.", collapse = ''))
  cat(lr, lr, sep = '')
  for (i in flags){
    x = get(paste(i, '.loc', sep = ''))
    value = args[x + 1]
    if (length(value) > 0){assign(paste(i), value, envir = .GlobalEnv)}
    if (length(value) == 0){assign(paste(i), NULL, envir = .GlobalEnv)}
    cat(paste(lr, i, ':\t', args[x + 1], collapse = ''))}
  cat(lr, lr, lr, sep = '')}


# A function to fill unspecified arguments with defaults (default = # Def:).
assign_empty_args = function(){
  if (length(d) == 0){assign('d', in.dir, envir = .GlobalEnv)} # Def: current directory
  if (length(o) == 0){assign('o', out.dir, envir = .GlobalEnv)} # Def: current directory
  if (length(e) == 0){assign('e', ex.dir, envir = .GlobalEnv)} # Def: current directory
  if (length(u) == 0){assign('u', 'm', envir = .GlobalEnv)} # Def: metric units
  if (length(fn) == 0){assign('fn', 'out', envir = .GlobalEnv)} # Def: output file name will be 'out.cli'
  if (length(fr) == 0){assign('fr', 'f', envir = .GlobalEnv)} # Def: not first run
  if (length(mp) == 0){assign('mp', 't', envir = .GlobalEnv)} # Def: multicore operation
  if (length(qc) == 0){assign('qc', 'f', envir = .GlobalEnv)} # Def: don't check quality
  if (length(fd) == 0){assign('fd', 'f', envir = .GlobalEnv)} # Def: don't fill data
  if (length(pd) == 0){assign('pd', 'f', envir = .GlobalEnv)} # Def: don't plot data
  if (length(ed) == 0){assign('ed', 1, envir = .GlobalEnv)} # Def: export data in R binary file format
  if (length(cp) == 0){assign('cp', 'f', envir = .GlobalEnv)} # Def: non-cumulative precipitation data
  if (length(cv) == 0){assign('cv', '0.0', envir = .GlobalEnv)} # Def: CLIGEN Version Unspecified
  if (length(sm) == 0){assign('sm', 1, envir = .GlobalEnv)} # Def: continuous simulation mode
  if (length(bp) == 0){assign('bp', 1, envir = .GlobalEnv)} # Def: breakpoint data used
  if (length(wi) == 0){assign('wi', 1, envir = .GlobalEnv)} # Def: wind information provided
  if (length(tz) == 0){assign('tz', 'GMT', envir = .GlobalEnv)} # Def: UTC (GMT) Timezone
  if (length(ei) == 0){assign('ei', 'f', envir = .GlobalEnv)} # Def: do not calculate erosion indices
  if (length(ee) == 0){assign('ee', 'BF', envir = .GlobalEnv)} # Def: use the Brown Foster (BF) energy equation
  if (length(alt) == 0){assign('alt', 'f', envir = .GlobalEnv)} # Def: alternative data provided
  if (length(sid) == 0){assign('sid', 1, envir = .GlobalEnv)} # Def: use first storm in list
  if (length(sdt) == 0){assign('sdt', 'start', envir = .GlobalEnv)} # Def: use earliest acceptable datetime
  if (length(edt) == 0){assign('edt', 'end', envir = .GlobalEnv)} # Def: use latest acceptable datetime
  if (length(rtb) == 0){assign('rtb', 't', envir = .GlobalEnv)} # Def: round time bounds
  if (length(tth) == 0){assign('tth', 6, envir = .GlobalEnv)} # Def: 6-hour time (break b/w storms)
  if (length(dth) == 0){assign('dth', 1.27, envir = .GlobalEnv)} # Def: 1.27 mm depth (break b/w storms)
  if (length(qcth) == 0){assign('qcth', 0.95, envir = .GlobalEnv)} # Def: 3 standard deviations
  if (length(dtf1) == 0){assign('dtf1', '%m/%d/%Y %H:%M', envir = .GlobalEnv)} # Def: YYYYMMDDHHMMSS
  if (length(dtf2) == 0){assign('dtf2', dtf1, envir = .GlobalEnv)} # Def: same as dtf1 (input or default)
  if (length(dtf3) == 0){assign('dtf3', dtf1, envir = .GlobalEnv)}} # Def: same as dtf1 (input or default)


# A function to halt execution for invalid arguments.
check_args = function(){
  tf.patterns = paste('t', 'f', collapse = '|')
  u.patterns = paste('m', 'e', collapse = '|')
  if (grepl(fr, tf.patterns, ignore.case = T) != T){stop("Invalid Argument: The 'first run' option [-fr] must be specified as 't' (true) or 'f' (false).")}
  if (grepl(mp, tf.patterns, ignore.case = T) != T){stop("Invalid Argument: The 'multiprocessing' option [-mp] must be specified as 't' (true) or 'f' (false).")}
  if (grepl(qc, tf.patterns, ignore.case = T) != T){stop("Invalid Argument: The 'quality checking' option [-qc] must be specified as 't' (true) or 'f' (false).")}
  if (grepl(fd, tf.patterns, ignore.case = T) != T){stop("Invalid Argument: The 'fill data' option [-fd] must be specified as 't' (true) or 'f' (false).")}
  if (grepl(pd, tf.patterns, ignore.case = T) != T){stop("Invalid Argument: The 'plot data' option [-pd] must be specified as 't' (true) or 'f' (false).")}
  if (grepl(cp, tf.patterns, ignore.case = T) != T){stop("Invalid Argument: The 'cumulative precipitation' option [-cp] must be specified as 't' (true) or 'f' (false).")}
  if (grepl(ei, tf.patterns, ignore.case = T) != T){stop("Invalid Argument: The 'erosion indices' option [-ei] must be specified as 't' (true) or 'f' (false).")}
  if (grepl(rtb, tf.patterns, ignore.case = T) != T){stop("Invalid Argument: The 'round time bounds' option [-rtb] must be specified as 't' (true) or 'f' (false).")}
  if (grepl(alt, tf.patterns, ignore.case = T) != T){stop("Invalid Argument: The 'alternative data' option [-alt] must be specified as 't' (true) or 'f' (false).")}
  if (length(grepl(u, u.patterns, ignore.case = T)) == 0){stop("Invalid Argument: The 'units' option [-u] must be specified as 'm' (metric) or 'e' (english) followed by any exceptions.")}
  if ((tz %in% OlsonNames()) == F){stop("Invalid Argument: Time zone option [-tz] not supported. Check 'OlsonNames()' in R documentation for supported time zones.")}
  #if (length(sdt) > 0){stop("Invalid Argument: Start datetime [-sdt] must be specified as datetime format [-dtf1] (Default: '%m/%d/%Y %R').")}
  #if (length(edt) > 0){stop("Invalid Argument: End datetime [-edt] must be specified as datetime format [-dtf1] (Default: '%m/%d/%Y %R').")}
  if (bp == 0){stop("Unsupported Argument: Non-breakpoint format output [-bp 0] not yet supported.")}}


# A function to load all R package dependencies.
load_packages = function(){
  t.time = system.time({
    cat('Loading R package dependencies... ')
    lapply(package.list, library, lib.loc = lib.dir, character.only = T, quietly = T, verbose = F)})
  cat('Completed in', t.time[3],'seconds.', lr, lr)}


# A function to load the input file used in calculations.
load_input_file = function(){
  setwd(d)
  t.time = system.time({
    txt = grep('.txt', f, ignore.case = T)
    csv = grep('.csv', f, ignore.case = T)
    if (sum(txt, csv) == 0){
      stop("The input file does not contain an acceptable extension (.txt or .csv).")}
    if (sum(txt, csv) > 1){
      stop("The input file contains more than one acceptable extension.")}
    cat('Loading input file... ')
    if (length(txt) == 1){
      file = suppressMessages(read_tsv(f))}
    if (length(csv) == 1){
      file = suppressMessages(read_csv(f))}})
  cat('Completed in', t.time[3],'seconds.', lr, lr)
  setwd(start.wd)
  return(file)}


# A function to check the input file format.
check_input_format = function(file){
  file = as.data.frame(file)
  
  # Check R data conversion.
  if(is.data.frame(file) == F){stop("The input file could not be stored as a data frame.")}
  
  # Check input variables.
  oldNames = colnames(file)
  vars = c('DT_1', 'PRECIP', 'DT_3', 'MAX_TEMP', 'MIN_TEMP', 'SO_RAD', 'W_VEL', 'W_DIR', 'DP_TEMP')
  if(toupper(alt) == 'T'){vars = c('DT_1', 'PRECIP', 'DT_2', 'AIR_TEMP', 'REL_HUM', 'DT_3', 'SO_RAD', 'W_VEL', 'W_DIR')}
  present = which(vars %in% oldNames)
  missing = vars[-present]
  if(length(missing) > 0){cat('Some expected variables are missing:', missing, lr, lr); stop()}
  return(file)}


# A function to load input files in a directory.
load_input_directory = function(){
  setwd(d)
  files = dir(d)
  create_cluster(length(files))
  t.time = system.time({
    cat('Loading input files... ')
    file = foreach(i = 1:length(files), .packages = 'readr') %dopar% {
      txt = grep('.txt', files[i], ignore.case = T)
      csv = grep('.csv', files[i], ignore.case = T)
      if (sum(txt, csv) == 0){
        stop("The input file does not contain an acceptable extension (.txt or .csv).")}
      if (sum(txt, csv) > 1){
        stop("The input file contains more than one acceptable extension.")}
      if (length(txt) == 1){
        return(suppressMessages(read_tsv(files[i])))}
      if (length(csv) == 1){
        return(suppressMessages(read_csv(files[i])))}}})
  cat('Completed in', t.time[3],'seconds.', lr, lr)
  kill_cluster()
  setwd(start.wd)
  return(file)}


# A function to check for missing columns and pad them with NA.
preprocess_file = function(file){
  t.time = system.time({
    cat('Preprocessing data... ')
    vars = c('STATION', 'TZ', 'LAT', 'LON', 'ELEV', 'DT_1', 'PRECIP', 'DT_2', 'AIR_TEMP', 'REL_HUM',
             'DT_3', 'MAX_TEMP', 'MIN_TEMP', 'SO_RAD','W_VEL', 'W_DIR', 'DP_TEMP')
    for (i in vars){
      logic = i %in% colnames(file)
      if (logic == F){
        old_names = colnames(file)
        file = cbind(file, NA)
        colnames(file) = c(old_names, i)}}})
  cat('Completed in', t.time[3],'seconds.', lr, lr)
  return(file)}


# A function to split data for parallel or standard processing.
split_data = function(file){
  t.time = system.time({
    cat('Splitting data by station... ')
    stats = na.omit(unique(file$STATION))
    if(length(stats) > 1){file = split(file, file$STATION)}
    if(length(stats) <= 1){file = list(file)}})
  cat('Completed in', t.time[3],'seconds.', lr, lr)
  return(file)}


# A function to create the multiprocessing virtual cluster environment.
create_cluster = function(s){
  cat('Creating multiprocessing virtual cluster... ')
  cores = detectCores()
  cluster = makeCluster(min(s, cores))
  registerDoParallel(cluster)
  cat('Done.', lr, lr)}


# A function to build a hashed R environment (slow construction, fastest lookup, flexible values, named keys only).
hash_env = function(k, v){
  if (length(k) == length(v)){
    my_env = new.env(hash = T)
    for (i in paste(k)){my_env[[i]] = v}}
  return(myenv)}


# A function to build an Rcpp hash map (fast construction, fast lookup, atomic values, atomic keys).
hash_rcpp = function(k, v){
  if (length(k) == length(v)){my_hm = hashmap(k, v)}
  return(my_hm)}


# A function to store data for processing.
store_data = function(file){
  file = as.data.frame(file[[1]], stringsAsFactors = F)
  long.vars = c('DT_1', 'PRECIP', 'DT_2', 'AIR_TEMP', 'REL_HUM', 'DT_3',
                'MAX_TEMP', 'MIN_TEMP', 'SO_RAD','W_VEL', 'W_DIR', 'DP_TEMP')
  short.vars = c('STATION', 'TZ', 'LAT', 'LON', 'ELEV', 'OBS_YRS', 'B_YR', 'YRS_SIM')
  for (i in long.vars){
    if (is.null(file[[i]]) == T){assign(i, NA)}
    if (is.null(file[[i]]) == F){assign(i, file[[i]])}}
  for (i in short.vars){
    if (is.null(file[[i]]) == T){assign(i, NA)}
    if (is.null(file[[i]]) == F){assign(i, file[[i]][1])}}
  data = list()
  data[[1]] = data.frame(DT_1, PRECIP)
  data[[2]] = data.frame(DT_2, AIR_TEMP, REL_HUM)
  data[[3]] = data.frame(DT_3, MIN_TEMP, MAX_TEMP, SO_RAD, W_VEL, W_DIR, DP_TEMP)
  data[[4]] = c(STATION, TZ, LAT, LON, ELEV, OBS_YRS, B_YR, YRS_SIM)
  names(data[[4]]) = short.vars
  return(data)}


# A function to change type to dataframe and class to numeric.
convert_data = function(data){
  for (i in 1:3){
    tmp = as.data.frame(data[[i]], stringsAsFactors = F)
    for (j in 2:ncol(tmp)){
      tmp[[j]] = as.numeric(tmp[[j]])}
    data[[i]] = tmp}
  return(data)}


# A function to calculate duration data.
create_duration_data = function(data){

  # Loop over each of the variable groups.
  checked_tz = check_tz(data)
  dt_list = c('DT_1', 'DT_2', 'DT_3')
  dtf_list = c(dtf1, dtf2, dtf3)
  for (i in 1:3){
    if (length(na.omit(data[[i]][[dt_list[i]]])) > 0){
      data[[i]][[dt_list[i]]] = as.POSIXct(data[[i]][[dt_list[i]]], tz = checked_tz, format = dtf_list[i])}
    if (length(na.omit(data[[i]][[dt_list[i]]])) == 0){data[[i]][[dt_list[i]]] = NA}
      dif = difftime(tail(data[[i]][[dt_list[i]]], -1), head(data[[i]][[dt_list[i]]], -1), units = 'mins')
      dif = as.numeric(dif)
      dif = c(dif[1], dif)
      data[[i]][['DUR']] = dif}
  
  # Keep only positive precipitation values and potential storm starts.
  p_rows = which(data[[1]][['PRECIP']] != 0)
  z_rows = which(data[[1]][['PRECIP']] == 0)
  s_rows = p_rows-1
  b_rows = intersect(z_rows, s_rows)
  data[[1]] = data[[1]][union(p_rows, b_rows),]
  data[[1]] = data[[1]][order(data[[1]][['DT_1']]),]
  return(data)}


# A function to convert units from English to metric.
convert_units = function(data){
  var.list = c('PRECIP', 'AIR_TEMP', 'MAX_TEMP', 'MIN_TEMP', 'SO_RAD', 'W_VEL', 'DP_TEMP', 'ELEV')
  
  # Parse arguments.
  if (length(u.loc) == 0){vars = NULL}
  if (length(u.loc) > 0){
    x = grep('-', args)
    x = x[x >= u.loc]
    start = x[1]+2
    end = min(x[2]-1, max(length(args)), na.rm = T)
    vars = toupper(args[start:end])
    if (start > end){vars = NA}}

  # Handle solar radiation (which must be in english units as opposed to metric units).
  if (length(grep('SO_RAD', vars, ignore.case = T)) > 0){vars = vars[!grepl('SO_RAD', vars, ignore.case = T)]}
    else {vars = na.omit(c(vars, 'SO_RAD'))}
  
  # Most or all units are metric (convert exceptions).
  if (toupper(u) == 'M'){}
  
  # Most or all units are english (do not convert exceptions).
  if (length(vars) == 0){vars = NA}
  if (toupper(u) == 'E'){vars = var.list[!grepl(paste(vars, collapse = '|'), var.list, ignore.case = T)]}

  # Perform simple conversions.
  if ('PRECIP' %in% vars){data[[1]][['PRECIP']] = data[[1]][['PRECIP']]*25.4} # Conversion from in to mm
  if ('MAX_TEMP' %in% vars){data[[3]][['MAX_TEMP']] = (data[[3]][['MAX_TEMP']] - 32) * 5/9} # Conversion from F to C
  if ('MIN_TEMP' %in% vars){data[[3]][['MIN_TEMP']] = (data[[3]][['MIN_TEMP']] - 32) * 5/9} # Conversion from F to C
  if ('AIR_TEMP' %in% vars){data[[2]][['AIR_TEMP']] = (data[[2]][['AIR_TEMP']] - 32) * 5/9} # Conversion from F to C
  if ('DP_TEMP' %in% vars){data[[3]][['DP_TEMP']] = (data[[3]][['DP_TEMP']] - 32) * 5/9} # Conversion from F to C
  if ('SO_RAD' %in% vars){data[[3]][['SO_RAD']] = data[[3]][['SO_RAD']] * data[[3]][['DUR']] * 60 / 41840} # Conversion from W/m^2 to Langleys
  if ('W_VEL' %in% vars){data[[3]][['W_VEL']] = data[[3]][['W_VEL']] * 0.44704} # Conversion from mph to m/s
  if ('ELEV' %in% vars && length(na.omit(data[[4]][['ELEV']])) > 0){ # Make sure elevation was provided
    data[[4]][['ELEV']] = as.numeric(data[[4]][['ELEV']]) * 0.3048} # Conversion from ft to m
  return(data)}


# A function to check input timezone and set to default if not supported.
check_tz = function(data){
  stat_data = as.data.frame(unname(data[[4]]), stringsAsFactors = F)
  if (length(na.omit(data[[4]][['TZ']])) > 0){tz_input = data[[4]][['TZ']]}
    else {tz_input = NA}
  if (length(na.omit(tz_input)) == 0){tz_input = tz}
  tz_check = which(OlsonNames() == tz_input)
  tz_input = OlsonNames()[tz_check]
  if (length(tz_check) != 1){tz_input = 'GMT'}
  Sys.setenv(TZ = tz_input)
  return(tz_input)}


# A function to obtain an acceptable period of data (sm = 1) or storm event (sm = 2).
trim_data = function(data){
  checked_tz = check_tz(data)
  data = break_storms(data)
  maxs = c(max(data[[1]][['DT_1']], na.rm = T), max(data[[2]][['DT_2']], na.rm = T), max(data[[3]][['DT_3']], na.rm = T))
  mins = c(min(data[[1]][['DT_1']], na.rm = T), min(data[[2]][['DT_2']], na.rm = T), min(data[[3]][['DT_3']], na.rm = T))
  start = max(mins, na.rm = T)
  end = min(maxs, na.rm = T)

  # Trim data to exact calendar year(s) based on user inputs.
  if (sm == 1){
    bounds = time_bounds(start, end, checked_tz)
    dt_list = c('DT_1', 'DT_2', 'DT_3')
    for (i in 1:3){
      data[[i]] = data[[i]][data[[i]][[dt_list[i]]] >= bounds[1],]
      data[[i]] = data[[i]][data[[i]][[dt_list[i]]] <= bounds[2],]}}
  
  # Store expected number of days for final checking.
  daysCount <<- difftime(bounds[2], bounds[1], units = 'days')

  # Record station observation data.
  data[[4]][['B_YR']] = format(bounds[1], format = '%Y')
  data[[4]][['OBS_YRS']] = as.numeric(diff.Date(c(bounds[3], bounds[4])))/365.2425
  data[[4]][['YRS_SIM']] = as.numeric(diff.Date(c(bounds[1], bounds[2])))/365.2425
  return(data)}


# A function to calculate breaks between storms.
break_storms = function(data){
  checked_tz = check_tz(data)
  data[[1]] = cum_to_inc(data[[1]])
  data[[1]] = identify_storms(data[[1]])
  if (toupper(ei) == 'T'){data[[1]] = int_30m(data[[1]])}
  data[[7]] = split(data[[1]], data[[1]][['EVENT_ID']])
  return(data)}


# A function to convert cumulative precipitation data to incremental data.
cum_to_inc = function(precip_data){
  if (toupper(cp) == 'T'){
    difs = c(0, diff(as.numeric(precip_data[['PRECIP']])))
    difs[which(difs < 0)] = precip_data[['PRECIP']][which(difs < 0)]
    precip_data[['PRECIP']] = as.numeric(difs)}
  zeros = which(precip_data[['PRECIP']] == 0)
  if (length(zeros) > 0){precip_data = precip_data[-zeros,]}
  precip_data[['INTENSITY']] = precip_data[['PRECIP']]/(precip_data[['DUR']]/60)
  return(precip_data)}


# A function to identify storm events.
identify_storms = function(precip_data){
  dates = as.POSIXlt(precip_data[['DT_1']])
  dif = c(0, difftime(tail(precip_data[['DT_1']], -1), head(precip_data[['DT_1']], -1), units = 'mins'))
  precip_data[['ANT_TIME']] = dif
  precip_data[['CUM_TIME']] = cumsum(precip_data[['ANT_TIME']])
  precip_data = evaluate_connectivity(precip_data)
  event_id = c()
  counter = 1
  for (i in 2:nrow(precip_data)){
    e_con_bef = precip_data[['E_CON_BEF']][i]
    e_con_aft = precip_data[['E_CON_AFT']][i]
    p_con_bef = precip_data[['E_CON_BEF']][i-1]
    p_con_aft = precip_data[['E_CON_AFT']][i-1]
    if (((e_con_bef == F && e_con_aft == F) || (e_con_aft == T && p_con_aft == F) || (p_con_bef == T && e_con_bef == F)) && p_con_aft == F){counter = counter + 1}
    event_id = append(event_id, counter)}
  precip_data[['EVENT_ID']] = c(1, event_id)
  return(precip_data)}


# A function to evaluate storm event connectivity.
evaluate_connectivity = function(precip_data){
  cum_depth.before = c()
  cum_depth.after = c()
  rows = ceiling(as.numeric(tth)*60/min(precip_data[['DUR']][precip_data[['DUR']] > 0]))
  for (i in 1:nrow(precip_data)){
    now = precip_data[['CUM_TIME']][i]
    indexWindow = c(max(i-rows, 1):min(i+rows, nrow(precip_data)))
    cumtimeWindow = precip_data[['CUM_TIME']][indexWindow]
    depthWindow = precip_data[['PRECIP']][indexWindow]
    start = max(0, now - as.numeric(tth)*60)
    end = now + as.numeric(tth)*60
    after.start = cumtimeWindow >= start
    before.now = cumtimeWindow < now
    after.now = cumtimeWindow > now
    before.end = cumtimeWindow <= end
    tmp.before = sum(depthWindow[as.logical(before.now * after.start)], na.rm = T)
    tmp.after = sum(depthWindow[as.logical(before.end * after.now)], na.rm = T)
    cum_depth.before = append(cum_depth.before, tmp.before)
    cum_depth.after = append(cum_depth.after, tmp.after)}
  precip_data[['P_SUM_BEF']] = cum_depth.before
  precip_data[['P_SUM_AFT']] = cum_depth.after
  precip_data[['E_CON_BEF']] = F
  precip_data[['E_CON_AFT']] = F
  precip_data[['E_CON_BEF']][which(precip_data[['P_SUM_BEF']] > as.numeric(dth))] = T
  precip_data[['E_CON_AFT']][which(precip_data[['P_SUM_AFT']] > as.numeric(dth))] = T
  return(precip_data)}


# A function to calculate 30-minute intensities.
int_30m = function(precip_data){
  int30 = c()
  for (i in 1:nrow(precip_data)){ #### EXECUTION TIME KILLER ####
    now = precip_data[['CUM_TIME']][i]
    start = max(0, now - 30)
    end = now
    after.start = precip_data[['CUM_TIME']] > start
    before.now = precip_data[['CUM_TIME']] <= now
    rows = as.logical(before.now * after.start)
    x = precip_data[['INTENSITY']][rows]
    w = precip_data[['DUR']][rows]
    if (sum(w) > 30){
      w[1] = 30 - sum(w[-1])}
    if (sum(w) < 30){
      x = append(x, 0)
      w = append(w, 30-sum(w))}
    last30 = weighted.mean(x, w, na.rm = T)
    int30 = append(int30, last30)}
  precip_data[['30_MIN_INT']] = int30
  return(precip_data)}


# A function to find an acceptable calendar year start and end datetime.
time_bounds = function(start, end, checked_tz){
  if (toupper(sdt) == 'START'){first.dt = start}
  if (toupper(sdt) != 'START'){first.dt = max(c(strptime(sdt, format = dtf1, tz = checked_tz), start), na.rm = T)}
  if (toupper(edt) == 'END'){last.dt = end}
  if (toupper(edt) != 'END'){last.dt = min(strptime(edt, format = dtf1, tz = checked_tz), end, na.rm = T)}
  good.start = start_of_year(first.dt, checked_tz)
  good.end = end_of_year(last.dt, checked_tz)
  bounds = c(good.start, good.end, first.dt, last.dt)
  if (good.start > good.end){stop(lr, lr, 'Invalid Date Range: At least one full calendar year must be specified with [-sdt] and [-edt].', lr, lr, collapse = '')}
  return(bounds)}


# A function to find the exact beginning of the next full calendar year.
start_of_year = function(date, tz_input){
  real.start = as.POSIXlt(date, format = dtf1, tz = tz_input)
  good.start = real.start
  rounded.start = real.start

  # Determine a good start for the complete data.
  good.start$mon = 0
  good.start$mday = 1
  good.start$hour = 0
  good.start$min = 0
  good.start$sec = 0
  
  # Round to the start of the first day of complete data.
  rounded.start$hour = 0
  rounded.start$min = 0
  rounded.start$sec = 0
  
  # Use the rounded start of complete data.
  if (toupper(rtb) == 'T'){if (rounded.start > good.start){good.start$year = good.start$year + 1}}
  
  # Use the exact start of complete data.
  if (toupper(rtb) == 'F'){if (real.start > good.start){good.start$year = good.start$year + 1}}
  
  return(good.start)}


# A function to find the exact end of the last full calendar year.
end_of_year = function(date, tz_input){
  real.end = as.POSIXlt(date, format = dtf1, tz = tz_input)
  good.end = real.end
  rounded.end = real.end
  
  # Determine a good end for the complete data.
  good.end$mon = 11
  good.end$mday = 31
  good.end$hour = 23
  good.end$min = 59
  good.end$sec = 59
  
  # Round to the end of the last day of complete data.
  rounded.end$hour = 23
  rounded.end$min = 59
  rounded.end$sec = 59
  
  # Use the rounded end of complete data.
  if (toupper(rtb) == 'T'){if (rounded.end < good.end){good.end$year = good.end$year - 1}}
  
  # Use the exact end of complete data.
  if (toupper(rtb) == 'F'){if (real.end < good.end){good.end$year = good.end$year - 1}}
  
  return(good.end)}


# A function to check data quality.
check_quality = function(data, x){
  data = build_rate_data(data, x)
  #outliers = outlier_test(data, x)
  # Check for suspect single values, differences, and rates.
  # Check for suspect extended periods.
  # Remove questionable data.
  #times = c(1, 5, 10, 30, 60, 1440, 10080, 40320)
  return(data)}


# A function to extract rates from breakpoint format data.
build_rate_data = function(data, x){
  
  # Define global physical limits in the format: c(max, min).
  precip = c(2500, 0)  # in mm (a sum of depth)
  ar.tmp = c(60, -90)  # in C (an average temperature)
  rel.hm = c(1000, 0)  # in % (an average percentage)
  mn.tmp = c(60, -90)  # in C (an average temperature)
  mx.tmp = c(60, -90)  # in C (an average temperature)
  so.rad = c(2500, 0)  # in langleys (a sum of energy)
  wd.vel = c(120, 0)   # in m/s (an average velocity)
  wd.dir = c(360, 0)   # in degrees (an average angle)
  dp.tmp = c(40, -25)  # in C (an average temperature)
  
  # Build lists.
  data[[5]] = list()
  var.list = list(c('PRECIP'), c('AIR_TEMP', 'REL_HUM'), c('MIN_TEMP', 'MAX_TEMP', 'SO_RAD', 'W_VEL', 'W_DIR', 'DP_TEMP'))
  physical.limits = list(list(precip), list(ar.tmp, rel.hm), list(mn.tmp, mx.tmp, so.rad, wd.vel, wd.dir, dp.tmp))
  
  # Loop over datetime groups.
  for (i in x){
    DT = data[[i]][[paste('DT_', i, sep = '')]]
    DUR = data[[i]][['DUR']]
    tmp = as.data.frame(cbind(DT, NA))
    names(physical.limits[[i]]) = var.list[[i]]
    
    # Loop over variable groups and build tables.
    for (j in var.list[[i]]){
      data[[i]][[j]][data[[i]][[j]] > physical.limits[[i]][[j]][[1]]] = physical.limits[[i]][[j]][[1]]
      data[[i]][[j]][data[[i]][[j]] < physical.limits[[i]][[j]][[2]]] = physical.limits[[i]][[j]][[2]]
      tmp[[paste(j, '_VAR', sep = '')]] = data[[i]][[j]]
      tmp[[paste(j, '_RATE', sep = '')]] = c(NA, diff(tmp[[paste(j, '_VAR', sep = '')]]))/DUR}
    tmp = tmp[,-2]
    data[[5]][[i]] = tmp}
  
  return(data)}


# A function to test for outliers.
outlier_test = function(data, x){
  var.list = list(c('PRECIP'), c('AIR_TEMP', 'REL_HUM'), c('MIN_TEMP', 'MAX_TEMP', 'SO_RAD', 'W_VEL', 'DP_TEMP'))
  
  # Loop over variable groups and perform signal processing (exclude wind direction).
  for (i in x){
    for (j in var.list[[i]]){
      
      # Get datetime, state, and rate data (by variable name).
      cols = c(1, grep(j, names(data[[5]][[i]])))
      tmp = data[[5]][[i]][,cols]

      # Replace infinite and nan values with NA and skip if n < 25.
      tmp[,2][is.infinite(tmp[,2]) | is.nan(tmp[,2])] = NA
      tmp[,3][is.infinite(tmp[,3]) | is.nan(tmp[,3])] = NA
      if (nrow(na.omit(tmp)) < 25){next()}  # Requirement for Rosner Test
      
      # Store state and rate data as a vector.
      x.v = tmp[,2]
      x.r = tmp[,3]

      # Use a sample of rate data (with NAs removed) for testing normality and estimating transformation parameters.
      vec = sample(x = na.omit(x.r), size = min(5000, length(na.omit(x.r)), na.rm = T), replace = F)
      #check_normality(vec, j, '_norm_test')
      t_vec = LW_transform(vec)
      #check_normality(t_vec, j, '_norm_test_LW_trans.pdf')
      }}
  
      stop_quietly()
      rosnerTest(t_vec, k = 100, alpha = 0.05)}


# A function to test normality assumptions of vector data.
check_normality = function(vec, j, name){}


# A function to perform a Lambert-W transformation of heavy tail data.
LW_transform = function(vec){
  mod.Lh = MLE_LambertW(vec, distname = "normal", type = "h")
  t_vec = get_input(mod.Lh)
  # summary(mod.Lh) # Print option
  return(t_vec)}


# A function to perform a Jones-Pewsey transformation of light tail data.
JP_transform = function(vec){
  epsilon = skewness(vec)
  delta = kurtosis(vec)
  fs = function(vec,epsilon,delta){
    dnorm(sinh(delta*asinh(vec)-epsilon))*delta*cosh(delta*asinh(vec)-epsilon)/sqrt(1+vec^2)}
  return(t_vec)}


# A function to normalize a vector (using maximum-minimum values).
normalize = function(vec){
  min.vec = min(vec, na.rm = T)
  cnt.vec = vec - min.vec
  max.vec = max(vec, na.rm = T)
  rng.vec = max.vec - min.vec
  nml.vec = cnt.vec/rng.vec
  return(nml.vec)}


# A function to fill missing data.
fill_data = function(data){
  
  # Parse filling arguments.
  x = grep('-', args)
  x = x[x >= fd.loc]
  start = x[1]+2
  end = min(x[2]-1, max(length(args)), na.rm = T)
  user_input = args[start:end]
  if (start > end){user_input = NA}
  
  # Fill missing single values if there are any.
  
  return(data)}


# A function to process precipitation data.
process_precip_data = function(data){
  checked_tz = check_tz(data)
  dates = format(data[[1]][['DT_1']], tz = checked_tz, format = "%Y%m%d")
  
  # Generate daily event metadata and find daily precipitation data.
  d.bps = aggregate(data[[1]][['PRECIP']], by = list(dates), FUN = length, simplify = T)
  d.events = aggregate(data[[1]][['EVENT_ID']], by = list(dates), FUN = unique, simplify = T)
  e.len = as.numeric(unlist(lapply(d.events[,2], function(x) length(x))))
  e.max = as.numeric(unlist(lapply(d.events[,2], function(x) max(x))))
  e.min = as.numeric(unlist(lapply(d.events[,2], function(x) min(x))))
  d.p.sum = aggregate(data[[1]][['PRECIP']], by = list(dates), FUN = sum, simplify = T)
  d.precip = cbind(d.bps, e.len, e.max, e.min, d.p.sum[,2])
  names(d.precip) = c('YYYYMMDD', 'D_BPS', 'E_LEN', 'E_MAX', 'E_MIN', 'PRECIP')
  data[[8]] = d.precip
  
  # Find monthly precipitation.
  m.p.sum = aggregate(d.p.sum[,2], by = list(format(as.Date(d.p.sum[,1], tz = checked_tz, format = '%Y%m%d'), format = '%Y%m')), FUN = sum, simplify = T)
  names(m.p.sum) = c('YYYYMM', 'PRECIP')
  data[[9]] = m.p.sum
  
  # Find monthly average precipitation.
  m.p.mean = aggregate(m.p.sum[,2], by = list(format(as.Date(paste(m.p.sum[,1], '01', sep = ''), tz = checked_tz, format = '%Y%m%d'), format = '%m')), FUN = mean, simplify = T)
  names(m.p.mean) = c('MM', 'PRECIP')
  data[[10]] = m.p.mean
  
  return(data)}


# A function to process optional sub-daily air temperature and relative humidity data.
process_alt_data = function(data){
  checked_tz = check_tz(data)
  dates = format(data[[2]][['DT_2']], tz = checked_tz, format = '%Y%m%d')
  
  # Find dew point temperature.
  dp.temp = cbind(dates, dew_point_temperature(data[[2]][['AIR_TEMP']], data[[2]][['REL_HUM']]))
  names(dp.temp) = c('YYYYMMDD', 'DP_TEMP')
  data[[2]][['DP_TEMP']] = as.numeric(dp.temp[,2])

  # Find daily alternative temperature data.
  d.t.min = aggregate(data[[2]][['AIR_TEMP']], by = list(dates), FUN = min, simplify = T)
  d.t.max = aggregate(data[[2]][['AIR_TEMP']], by = list(dates), FUN = max, simplify = T)
  d.dp.temp = aggregate(as.numeric(dp.temp[,2]), by = list(dates), FUN = mean, simplify = T)
  d.alt = cbind(d.t.min, d.t.max[,2], d.dp.temp[,2])
  names(d.alt) = c('YYYYMMDD', 'D_MIN_T', 'D_MAX_T', 'D_DP_T')
  data[[11]] = d.alt
  
  return(data)}


# A function to calculate dew point temperature from relative humidity and air temperature data.
dew_point_temperature = function(air_temp, rel_hum){
  rel_hum[rel_hum == 0] = 1
  A1 = 7.625
  B1 = 243.04
  top = B1 * (log(rel_hum/100) + (A1 * air_temp)/(B1 + air_temp))
  bottom = A1 - log(rel_hum/100) - (A1 * air_temp)/(B1 + air_temp)
  dp_temp = top / bottom
  return(dp_temp)}


# A function to process daily max/min temperature, solar radiation, wind speed and direction, and dew point temperature data.
process_daily_data = function(data){
  checked_tz = check_tz(data)
  
  # Find daily average data.
  dates = format(data[[3]][['DT_3']], tz = checked_tz, format = '%Y%m%d')
  tmin = aggregate(data[[3]][['MIN_TEMP']], by = list(dates), FUN = min, simplify = T)
  tmax = aggregate(data[[3]][['MAX_TEMP']], by = list(dates), FUN = max, simplify = T)
  dew = aggregate(data[[3]][['DP_TEMP']], by = list(dates), FUN = mean, simplify = T)
  wvel = aggregate(data[[3]][['W_VEL']], by = list(dates), FUN = mean, simplify = T)
  wdir = aggregate(data[[3]][['W_DIR']], by = list(dates), FUN = mean, simplify = T)
  
  # Find daily sum data.
  rad = aggregate(data[[3]][['SO_RAD']], by = list(dates), FUN = sum, simplify = T)
  
  # Assemble data.
  data[[12]] = cbind(tmin, tmax[,2], rad[,2], wvel[,2], wdir[,2], dew[,2])
  names(data[[12]]) = c('YYYYMMDD', 'MIN_TEMP', 'MAX_TEMP', 'SO_RAD', 'W_VEL', 'W_DIR', 'DP_TEMP')

  # Overwrite with optional alternative data.
  if (toupper(alt) == 'T'){
    data = use_alt_data(data)
    tmin = data[[12]][,c(1,2)]
    tmax = data[[12]][,c(1,3)]
    dew = data[[12]][,c(1,7)]}
  
  # Find monthly average data.
  m.tmin = aggregate(tmin[,2], by = list(format(as.Date(tmin[,1], tz = checked_tz, format = '%Y%m%d'), format = '%m')), FUN = mean, simplify = T)
  m.tmax = aggregate(tmax[,2], by = list(format(as.Date(tmax[,1], tz = checked_tz, format = '%Y%m%d'), format = '%m')), FUN = mean, simplify = T)
  m.rad = aggregate(rad[,2], by = list(format(as.Date(rad[,1], tz = checked_tz, format = '%Y%m%d'), format = '%m')), FUN = mean, simplify = T)
  m.wvel = aggregate(wvel[,2], by = list(format(as.Date(wvel[,1], tz = checked_tz, format = '%Y%m%d'), format = '%m')), FUN = mean, simplify = T)
  m.wdir = aggregate(wdir[,2], by = list(format(as.Date(wdir[,1], tz = checked_tz, format = '%Y%m%d'), format = '%m')), FUN = mean, simplify = T)
  m.dew = aggregate(dew[,2], by = list(format(as.Date(dew[,1], tz = checked_tz, format = '%Y%m%d'), format = '%m')), FUN = mean, simplify = T)
  data[[13]] = cbind(m.tmin, m.tmax[,2], m.rad[,2], m.wvel[,2], m.wdir[,2], m.dew[,2])
  names(data[[13]]) = c('MM', 'MIN_TEMP', 'MAX_TEMP', 'SO_RAD', 'W_VEL', 'W_DIR', 'DP_TEMP')
  
  return(data)}


# A function to replace daily data calculations of max, min, and dp temperature with alternative data.
use_alt_data = function(data){
  tmax = data[[11]][['D_MAX_T']]
  tmin = data[[11]][['D_MIN_T']]
  dew = data[[11]][['D_DP_T']]
  data[[12]][['MIN_TEMP']] = tmin
  data[[12]][['MAX_TEMP']] = tmax
  data[[12]][['DP_TEMP']] = dew
  names(data[[12]]) = c('YYYYMMDD', 'MIN_TEMP', 'MAX_TEMP', 'SO_RAD', 'W_VEL', 'W_DIR', 'DP_TEMP')
  return(data)}


# A function to calculate erosion indices.
calculate_erosion_indices = function(data){

  # Parse arguments for user specified equation.
  x = grep('-', args)
  x = x[x >= ee.loc]
  start = x[1]+2
  end = min(x[2]-1, max(length(args)), na.rm = T)
  user_input = args[start:end]
  if (start > end){user_input = NA}
  
  # Set energy equations: i is intensity in mm/hr.
  AH282 = parse(text = "0.119 + 0.0873 * log10(i)")
  AH537 = parse(text = "0.119 + 0.0873 * log10(i)")
  AH703 = parse(text = "0.119 + 0.0873 * log10(i)")
  BF = parse(text = "0.29 * (1 - 0.72 * exp(-0.05 * i))")
  MM = parse(text = "0.273 + 0.2168 * exp(-0.048 * i) - 0.4126 * exp(-0.072 * i)")
  USER = parse(text = paste(user_input))
  
  # Select equations to use.
  if (toupper(ee) == 'ALL'){eqn = c('AH282', 'AH537', 'AH703', 'BF', 'MM', 'USER')}
  if (toupper(ee) == 'AH282'){eqn = 'AH282'}
  if (toupper(ee) == 'AH537'){eqn = 'AH537'}
  if (toupper(ee) == 'AH703'){eqn = 'AH703'}
  if (toupper(ee) == 'BF'){eqn = 'BF'}
  if (toupper(ee) == 'MM'){eqn = 'MM'}
  if (toupper(ee) == 'USER'){eqn = 'USER'}
  
  # Loop over each equation.
  for (name in eqn){
    exp = get(name)
    
    # Loop over each storm.
    for (storm in 1:length(data[[7]])){
      i = data[[7]][[storm]][['INTENSITY']]

      # Limit intensity for some equations.
      if (name == 'AH537'){i[i > 76] = 76}
      if (name == 'AH703'){i[i > 76] = 76}

      # Evaluate energy expression for energy density and calculate kinetic energy for each intensity.
      data[[7]][[storm]][[paste(name, '_ED', sep = '')]] = eval(exp)
      data[[7]][[storm]][[paste(name, '_KE', sep = '')]] = data[[7]][[storm]][[paste(name, '_ED', sep = '')]] * data[[7]][[storm]][['PRECIP']]}}

  # Calculate and store other important storm parameters.
  dtimes = unname(unlist(lapply(data[[7]], function(x) x[['DT_1']][1])))
  depth = unname(unlist(lapply(data[[7]], function(x) sum(x[['PRECIP']], na.rm = T))))
  dur = unname(unlist(lapply(data[[7]], function(x) max(x[['CUM_TIME']], na.rm = T) - min(x[['CUM_TIME']], na.rm = T) + x[['DUR']][1])))
  pdur = unname(unlist(lapply(data[[7]], function(x) sum(x[['DUR']], na.rm = T))))
  ip = unname(unlist(lapply(data[[7]], function(x) max(x[['INTENSITY']], na.rm = T))))
  itw = unname(unlist(lapply(data[[7]], function(x) weighted.mean(x[['INTENSITY']], x[['DUR']], na.rm = T))))
  idw = unname(unlist(lapply(data[[7]], function(x) weighted.mean(x[['INTENSITY']], x[['PRECIP']], na.rm = T))))
  i30 = unname(unlist(lapply(data[[7]], function(x) max(x[['30_MIN_INT']], na.rm = T))))
  tp = unname(unlist(lapply(data[[7]], function(x) {
    t.vec = x[['CUM_TIME']] - min(x[['CUM_TIME']], na.rm = T) + x[['DUR']][1]
    tp.vec = which(x[['INTENSITY']] == max(x[['INTENSITY']], na.rm = T))
    return(median(t.vec[tp.vec], na.rm = T)/max(t.vec, na.rm = T))})))
  
  # Calculate storm kinetic energy.
  ke.list = lapply(eqn, function(x) {
    name = paste(x, '_ED', sep = '')
    out = unname(unlist(lapply(data[[7]], function(y) sum(y[[name]], na.rm = T))))
    return(out)})
  ke.names = unlist(lapply(eqn, function(x) paste(x, '_KE', sep = '')))
  names(ke.list) = ke.names

  # Calculate storm erosion indices.
  ei.list = lapply(names(ke.list), function(x) {
    y = ke.list[[x]]
    max.i30 = i30
    if (x == 'AH537_KE'){max.i30[max.i30 > 64] = 64}
    out = max.i30 * y
    return(out)})
  ei.names = unlist(lapply(eqn, function(x) paste(x, '_EI', sep = '')))
  names(ei.list) = ei.names
  
  # Convert outputs to dataframes.
  ke.df = list.cbind(ke.list)
  ei.df = list.cbind(ei.list)
  sp.df = as.data.frame(cbind(format(as.POSIXct(dtimes, origin = '1970-01-01')), depth, dur, pdur, pdur/dur, ip, tp, itw, idw, i30))
  names(sp.df) = c('DT', 'DEPTH', 'DUR', 'P_DUR', 'P_RATIO', 'PEAK_INT', 'PEAK_TIME', 'TIME_WM_INT', 'DEPTH_WM_INT', 'MAX_30_MIN_INT')
  
  # Store output.
  data[[14]] = cbind(sp.df, ke.df, ei.df)

  return(data)}


# A function to create graphical output.
graph_data = function(data, x){
  
  # Create directory structure.
  setwd(plot.dir)
  dir.list = c('INPUT', 'OUTPUT')
  for (j in dir.list){create_plot_directories(j)}
  
  # Loop over variable groups and variables.
  var.list = list(c('PRECIP'), c('AIR_TEMP', 'REL_HUM'), c('MIN_TEMP', 'MAX_TEMP', 'SO_RAD', 'W_VEL', 'DP_TEMP'))
  var.unit = list(c('mm'), c('C', '%'), c('C', 'C', 'Langleys', 'm/s', 'C'))
  for (i in x){
    for (j in var.list[[i]]){
      
      # Get datetime, state, and rate data (by variable name).
      cols = c(1, grep(j, names(data[[5]][[i]])))
      tmp = data[[5]][[i]][,cols]
      
      # Create INPUT directories and plots.
      setwd('INPUT')
      create_input_plots(j, var.unit[[i]][[which(var.list[[i]] == j)]], tmp)}}
  
  # Create OUTPUT directories.
  plot.list = c('ANNUAL', 'MONTHLY', 'DAILY', 'OTHER')
  for (i in plot.list){
    setwd(plot.dir)
    setwd('OUTPUT')
    create_plot_directories(i)
    setwd(i)
    
    # Create OUTPUT plots.
    if (i == 'ANNUAL'){annual_plots(data)}
    if (i == 'MONTHLY'){monthly_plots(data)}
    if (i == 'DAILY'){daily_plots(data)}
    #if (i == 'OTHER'){other_plots(data)}
    }
  
  setwd(home.dir)}


# A function to create directories for graphical outputs if they do not exist.
create_plot_directories = function(var){
  logic = dir.exists(toupper(var))
  if (logic == F){dir.create(var)}}


# A function to create plots for each variable.
create_input_plots = function(j, var.unit, tmp){
  create_plot_directories(j)
  setwd(j)
  
  # Get station name.
  if (toupper(fn) == 'STATION'){fn = data[[4]]['STATION']}
  
  # Set vectors.
  tmp = na.omit(tmp)
  dt = as.POSIXlt(tmp[,1], origin = '1970-01-01 00:00.00 UTC')
  var = tmp[,2]
  rate = tmp[,3]
  
  # Sample for normality plots.
  s_var = sample(var, min(5000, length(var)))
  s_rate = sample(rate, min(5000, length(rate)))
  
  # Plot variable state data if it is present.
  if (length(var) > 0){
    
    # Time Series
    pdf(paste(fn, '_', j, '_var_time_series.pdf', sep = ''), width = 6, height = 3, pointsize = 10)
    plot(dt, var, type = 'l', main = paste('Time series of ', j, sep = ''), xlab = 'Date', ylab = paste(j, ' (', var.unit, ')', sep = ''))
    dev.off()
    
    # Histogram
    pdf(paste(fn, '_', j, '_var_histogram.pdf', sep = ''), width = 6, height = 6, pointsize = 10)
    hist(var, main = paste('Histogram of ', j, sep = ''), xlab = paste(j, ' (', var.unit, ')', sep = ''))
    dev.off()
    
    # Normality
    pdf(paste(fn, '_', j, '_var_normality.pdf', sep = ''), width = 6, height = 6, pointsize = 10)
    test_norm(s_var)
    dev.off()}
  
  # Plot variable rate data if it is present.
  if (length(rate) > 0){
    
    # Time Series
    pdf(paste(fn, '_', j, '_rate_time_series.pdf', sep = ''), width = 6, height = 3, pointsize = 10)
    plot(dt, rate, type = 'l', main = paste('Time series of changes in ', j, sep = ''), xlab = 'Date', ylab = paste('Change in ', j, ' (', var.unit, ')', sep = ''))
    dev.off()
    
    # Histogram
    pdf(paste(fn, '_', j, '_rate_histogram.pdf', sep = ''), width = 6, height = 6, pointsize = 10)
    hist(rate, main = paste('Histogram of changes in ', j, sep = ''), xlab = paste('Change in ', j, ' (', var.unit, ')', sep = ''))
    dev.off()
    
    # Normality
    pdf(paste(fn, '_', j, '_rate_normality.pdf', sep = ''), width = 6, height = 6, pointsize = 10)
    test_norm(s_rate)
    dev.off()}
  
  setwd(plot.dir)}


# A function to create annual plots for output data.
annual_plots = function(data){
  
  # Plot for each daily dataset.
  d.list = c(8, 12)
  unit.list = c('Breakpoints', 'mm', 'C', 'C', 'Langleys/Day', 'm/s', 'Degrees (cc) from N', 'C')
  counter = 0
  for (i in d.list){
    tmp = data[[i]]
    if (i == 8){tmp = tmp[,-3:-5]; kind = 'sum';
      tmp = aggregate(tmp[,-1], by = list(format(as.Date(tmp[,1], format = '%Y%m%d'), format = '%Y')), FUN = sum)}
    if (i == 12){kind = 'mean';
      tmp = aggregate(tmp[,-1], by = list(format(as.Date(tmp[,1], format = '%Y%m%d'), format = '%Y')), FUN = mean)}
    
    # Plot for each variable.
    for (j in colnames(tmp)[-1]){
      counter = counter + 1
      unit = unit.list[counter]
      pdf(paste(fn, '_', j, '_annual_', kind, '.pdf', sep = ''), width = 6, height = 4, pointsize = 10)
      barplot(tmp[[paste(j)]], names.arg = tmp[,1], main = paste('Annual ', j, sep = ''), xlab = 'Year', ylab = paste(j, ' (', unit, ')', sep = ''))
      dev.off()}}
  
  setwd(plot.dir)}


# A function to create monthly plots for output data.
monthly_plots = function(data){
  
  # Plot for each monthly dataset.
  mn.list = c(10, 13)
  unit.list = c('mm', 'C', 'C', 'Langleys/Day', 'm/s', 'Degrees (cc) from N', 'C')
  counter = 0
  for (i in mn.list){
    tmp = data[[i]]

    # Plot for each variable.
    for (j in colnames(tmp)[-1]){
      counter = counter + 1
      unit = unit.list[counter]
      pdf(paste(fn, '_', j, '_monthly_means.pdf', sep = ''), width = 6, height = 4, pointsize = 10)
      barplot(tmp[[paste(j)]], names.arg = tmp[,1], main = paste('Monthly Mean ', j, sep = ''), xlab = 'Month (1-12)', ylab = paste(j, ' (', unit, ')', sep = ''))
      dev.off()}}
  
  setwd(plot.dir)}


# A function to create daily plots for output data.
daily_plots = function(data){
  
  # Plot for each daily dataset.
  d.list = c(8, 12)
  unit.list = c('Breakpoints', 'mm', 'C', 'C', 'Langleys/Day', 'm/s', 'Degrees (cc) from N', 'C')
  counter = 0
  for (i in d.list){
    tmp = data[[i]]
    if (i == 8){tmp = tmp[,-3:-5]; g.type = 'p'; kind = 'sum'}
    if (i == 12){g.type = 'l'; kind = 'mean'}

    # Plot for each variable.
    for (j in colnames(tmp)[-1]){
      counter = counter + 1
      unit = unit.list[counter]
      pdf(paste(fn, '_', j, '_daily_', kind, '.pdf', sep = ''), width = 6, height = 4, pointsize = 10)
      plot(as.Date(tmp[,1], format = '%Y%m%d'), tmp[[paste(j)]], type = g.type, main = paste('Daily ', j, sep = ''), xlab = 'Date', ylab = paste(j, ' (', unit, ')', sep = ''))
      dev.off()}}
  
  setwd(plot.dir)}


# A function to create other plots for output data.
other_plots = function(){
  setwd(plot.dir)}


# A function to export the primary data structure to file.
export_data = function(data){
  setwd(e)
  if (toupper(fn) == 'STATION'){fn = data[[4]]['STATION']}
  if (ed == 1){saveRDS(data, paste(fn, '.rds', sep = ''))}
  if (ed == 2){list.save(data, paste(fn, '.json', sep = ''))}
  setwd(start.wd)}


# A function to create header data for .cli file creation function.
generate_header_data = function(data){

  # Get station data.
  station = data[[4]][['STATION']]
  lat = format(round(as.numeric(data[[4]][['LAT']]), 4), justify = 'right', width = 8, nsmall = 4)
  lon = format(round(as.numeric(data[[4]][['LON']]), 4), justify = 'right', width = 9, nsmall = 4)
  elev = format(round(as.numeric(data[[4]][['ELEV']]), 2), justify = 'right', width = 6, nsmall = 2)
  oyr = format(round(as.numeric(data[[4]][['OBS_YRS']]), 0), justify = 'right', width = 3, nsmall = 0)
  byr = format(round(as.numeric(data[[4]][['B_YR']]), 0), justify = 'right', width = 4, nsmall = 0)
  syr = format(round(as.numeric(data[[4]][['YRS_SIM']]), 0), justify = 'right', width = 3, nsmall = 0)

  # Get monthly average data.
  m.min.t = data[[13]][,2]
  m.max.t = data[[13]][,3]
  m.sorad = data[[13]][,4]
  m.precip = data[[10]][,2]
  
  # Prepare fixed format header.
  h.1 = paste(' ', cv, lr,
              '   ', sm, '   ', bp, '   ', wi, lr,
              '   ', 'Station:', ' ', station, lr,
              ' Latitude Longitude Elevation (m) Obs. Years   Beginning Year  Years Simulated ', lr, sep = '')
  h.2 = paste(' ', lat, ' ', lon, '     ', elev, '         ', oyr, '           ', byr, '             ', syr, sep = '')
  h.3 = paste(lr, ' Observed monthly ave max temperature (C)', lr,
              ' ', paste(format(round(m.max.t, 1), justify = 'right', width = 5, nsmall = 1), collapse = ' '),
              lr, ' Observed monthly ave min temperature (C)', lr,
              ' ', paste(format(round(m.min.t, 1), justify = 'right', width = 5, nsmall = 1), collapse = ' '),
              lr, ' Observed monthly ave solar radiation (Langleys/day)', lr,
              ' ', paste(format(round(m.sorad, 1), justify = 'right', width = 5, nsmall = 1), collapse = ' '),
              lr, ' Observed monthly ave precipitation (mm)', lr,
              ' ', paste(format(round(m.precip, 1), justify = 'right', width = 5, nsmall = 1), collapse = ' '), sep = '')
  
  # Prepare fixed format, non-breakpoint format column headers.
  if (bp == 0){
    h.4 = paste(lr, ' Day Month Year  Prcp  Dur   TP     IP  T-Max  T-Min   Rad   W-Vel  W-Dir  T-Dew')
    h.5 = paste(lr, '                 (mm)  (h)               (C)    (C)   (L/d)  (m/s)  (Deg)   (C)')}
  
  # Prepare fixed format, breakpoint format column headers.
  if (bp == 1){
    h.4 = paste(lr, ' Day Month Year  Breaks  T-Max  T-Min   Rad   W-Vel  W-Dir  T-Dew')
    h.5 = paste(lr, '                   (#)    (C)    (C)   (L/d)  (m/s)  (Deg)   (C)')}
  
  # Combine and return.
  header = paste(h.1, h.2, h.3, h.4, h.5, sep = '')
  return(header)}


# A function to create export data for .cli file creation function.
generate_export_data = function(data){

  # Format date data.
  dates = data[[12]][,1]
  dy = format(as.integer(format(as.Date(dates, format = '%Y%m%d'), format = '%d')), justify = 'right', width = 2)
  mn = format(as.integer(format(as.Date(dates, format = '%Y%m%d'), format = '%m')), justify = 'right', width = 2)
  yr = format(as.integer(format(as.Date(dates, format = '%Y%m%d'), format = '%Y')), justify = 'right', width = 4)
  
  # Format daily data.
  raw_df = Reduce(function(...) merge(..., all=TRUE), list(data[[8]][,1:2], data[[12]]))
  tmp_df = raw_df
  
  # Increase nbrkpt count for non-increasing periods and storm starts.
  pr.start = 1
  previous.max.sid = 0
  for (i in 1:nrow(raw_df)){
    
    # Write body (breakpoint loop)
    if (is.na(raw_df[i, 2]) == F){
      pr.end = pr.start + raw_df[i, 2] - 1
      
      # Write breakpoints.
      for(j in pr.start:pr.end){

        # Increase for the first breakpoint (no antecedent time will exist).
        if (j == 1){tmp_df[i, 2] = tmp_df[i, 2] + 1}
        
        # Write zero increases when the period duration is less than the elapsed antecedent period time.
        if (data[[1]][['ANT_TIME']][j] > data[[1]][['DUR']][j]){tmp_df[i, 2] = tmp_df[i, 2] + 1}}
        
      # Setup for the next iteration.
      pr.start = pr.end + 1}}
  
  # Use new nbrkpt values.
  df = tmp_df
  df[is.na(df[,2]), 2] = 0

  # Format columns.
  nbrkpt = format(as.integer(df[,2]), justify = 'right', width = 3, nsmall = 0)
  tmin = format(round(as.numeric(df[,3]), 1), justify = 'right', width = 5, nsmall = 1)
  tmax = format(round(as.numeric(df[,4]), 1), justify = 'right', width = 5, nsmall = 1)
  rad = format(round(as.numeric(df[,5]), 1), justify = 'right', width = 5, nsmall = 1)
  wvel = format(round(as.numeric(df[,6]), 1), justify = 'right', width = 5, nsmall = 1)
  wdir = format(round(as.numeric(df[,7]), 1), justify = 'right', width = 5, nsmall = 1)
  dew = format(round(as.numeric(df[,8]), 1), justify = 'right', width = 5, nsmall = 1)

  # Combine and export.
  df_out = cbind(dy, mn, yr, nbrkpt, tmax, tmin, rad, wvel, wdir, dew)
  export = list(df_out, raw_df)
  return(export)}


# A function to write data to a .cli file.
create_cli_file = function(data, header, export){
  df = export[[1]]
  raw_df = export[[2]]
  precip_data = data[[1]]
  event_data = data[[8]]
  pr.start = 1
  e.count = 0
  previous.max.sid = 0
  if (nrow(raw_df) != ceiling(as.numeric(daysCount))){
    stop('There are missing data. Rerun and perform quality checking [-qc] and fill missing data [-fd].')}
  
  # Create file.
  setwd(o)
  if (toupper(fn) == 'STATION'){fn = data[[4]]['STATION']}
  of = paste(fn, '.cli', sep = '')
  file.create(of, overwrite = T)

  # Write header.
  write_file(header, of, append = F)
  
  # Write body (daily loop).
  for (i in 1:nrow(raw_df)){
    write_file(paste(lr, '  ', df[i,1], '   ', df[i,2], '  ', df[i,3], '    ', df[i,4], '   ', df[i,5], '  ', df[i,6],
                     '  ',   df[i,7], '  ',  df[i,8], '  ', df[i,9], '  ',   df[i,10], sep = ''), of, append = T)

    # Write body (breakpoint loop)
    if (is.na(raw_df[i, 2]) == F){
      e.count = e.count + 1
      current.max.sid = event_data[e.count, 4]
      current.min.sid = event_data[e.count, 5]
      pr.end = pr.start + raw_df[i, 2] - 1
      
      # Reset storm if SID (storm ID) increases.
      if (previous.max.sid < current.min.sid){
        pr.sum = 0}
      
      # Write breakpoints.
      for(j in pr.start:pr.end){
        date = as.POSIXlt(precip_data[['DT_1']][j])
        time = date[[3]] + date[[2]]/60 + date[[1]]/3600
        time.out = format(round(time, 3), justify = 'right', width = 6, nsmall = 3)
        
        # Write the first breakpoint (no antecedent time will exist).
        if (j == 1){
          time.2 = time - precip_data[['DUR']][j]/60
          time.out.2 = format(round(time.2, 3), justify = 'right', width = 6, nsmall = 3)
          p.out = format(round(pr.sum, 2), justify = 'right', width = 6, nsmall = 2)
          write_file(paste(lr, time.out.2, ' ', p.out, sep = ''), of, append = T)}
        
        # Write zero increases when the period duration is less than the elapsed antecedent period time.
        if (precip_data[['ANT_TIME']][j] > precip_data[['DUR']][j]){
          time.2 = time - precip_data[['DUR']][j]/60
          time.out.2 = format(round(time.2, 3), justify = 'right', width = 6, nsmall = 3)
          p.out = format(round(pr.sum, 2), justify = 'right', width = 6, nsmall = 2)
          write_file(paste(lr, time.out.2, ' ', p.out, sep = ''), of, append = T)}
        
        # Write increases in precipitation normally.
        pr.sum = pr.sum + precip_data[['PRECIP']][j]
        p.out = format(round(pr.sum, 2), justify = 'right', width = 6, nsmall = 2)
        write_file(paste(lr, time.out, ' ', p.out, sep = ''), of, append = T)}
      
      # Setup for the next iteration.
      pr.start = pr.end + 1
      previous.max.sid = current.max.sid}}
  
  setwd(start.wd)}
  

# A function to end multiprocessing.
kill_cluster = function(){
  cat('Killing multiprocessing virtual cluster... ')
  stopImplicitCluster()
  cat('Done.', lr, lr)}


# A function for printing 'data' objects (intended to be used primarily as a development utility).
view_data = function(data){
  for (i in 1:length(data)){
    print(class(data[[i]]))
    if(class(data[[i]]) == 'data.frame'){print(data[[i]][1:5,])}
    if(class(data[[i]]) == 'list'){print(data[[i]][1:5])}}}


# A function to stop program execution quietly.
stop_quietly = function(){
  opt = options(show.error.messages = FALSE)
  on.exit(options(opt))
  stop()}


# The main program function.
main = function(){
  
  # Process user input arguments.
  set_wds()
  parse_arg_locations()
  assign_args_to_vars()
  assign_empty_args()
  
  # First run installation.
  if (fr == 't'){
    install_dependencies()
    suppressMessages(load_packages())
    cat("Installation successful. WEPPCLIFF is now ready to run.",lr, collapse = "")
    stop_quietly()}
  
  # Read from file and store for processing.
  t.time = system.time({
    check_args()
    suppressMessages(load_packages())
    if (length(f) == 1){
      file = load_input_file()
      check_input_format(file)
      file = preprocess_file(file)
      file = split_data(file)}
    if (length(f) == 0){
      file = load_input_directory()}
    s = length(file)

    # Process multiple stations in parallel.
    if (toupper(mp) == 'T' && s > 1){
      cat('Detected', s, 'stations. Parallel processing has been enabled.', lr, lr)
      create_cluster(s)
      cat('Processing... see the log file (log.txt) for progress.', lr, lr)
      file.create("log.txt", overwrite = T)
      foreach(i=1:length(file), .export = export.list, .packages = package.list, .verbose = F) %dopar% {
        setwd(o)
        sink("log.txt", append = F)
        cat(paste('Processing ', i, ' of ', length(file), ' stations... ', sep = ''))
        data = store_data(file[i])
        data = convert_data(data)
        data = create_duration_data(data)
        data = convert_units(data)
        data = trim_data(data)
        if (toupper(qc) == 'T'){data = check_quality(data, x)}
        if (toupper(fd) == 'T'){data = fill_data(data)}
        data = process_precip_data(data)
        if (toupper(alt) == 'T'){data = process_alt_data(data)}
        data = process_daily_data(data)
        if (toupper(ei) == 'T'){data = calculate_erosion_indices(data)}
        if (toupper(pd) == 'T'){graph_data(data, x)}
        if (ed > 0){export_data(data)}
        header = generate_header_data(data)
        export = generate_export_data(data)
        create_cli_file(data, header, export)}
      kill_cluster()}
    
    # Process single station normally.
    if (mp == F || s <= 1){
      t.time = system.time({
        if (s > 1){
          cat('Detected', s, 'stations. Parallel processing has been disabled.', lr, lr)
          cat(paste('Processing ', i, ' of ', length(file), ' stations... ', sep = ''))}
        if (s == 1){
          cat('Detected 1 station. Parallel processing has been disabled.', lr, lr)
          cat(paste('Processing station... ', sep = ''))}
        data = store_data(file)
        data = convert_data(data)
        data = create_duration_data(data)
        data = convert_units(data)
        data = trim_data(data)
        if (toupper(qc) == 'T'){data = check_quality(data, x)}
        if (toupper(fd) == 'T'){data = fill_data(data)}
        data = process_precip_data(data)
        if (toupper(alt) == 'T'){data = process_alt_data(data)}
        data = process_daily_data(data)
        if (toupper(ei) == 'T'){data = calculate_erosion_indices(data)}
        if (toupper(pd) == 'T'){graph_data(data, x)}
        if (ed > 0){export_data(data)}
        header = generate_header_data(data)
        export = generate_export_data(data)
        create_cli_file(data, header, export)})
      cat('Completed in', t.time[3],'seconds.', lr, lr)}})
  
  cat('Program executed successfully in', t.time[3],'seconds... now exiting WEPPCLIFF script.', lr, lr)}


# Additional global variables.
lr = '\r\n'
x = 1:3
args = commandArgs(trailingOnly = T)
std.dtf = "%Y-%m-%d %H:M:%S"
start.wd = getwd()
flags = c('d', 'o', 'e', 'f', 'u', 'fn', 'fr', 'mp', 'qc', 'fd', 'pd', 'ed', 'cp', 'cv', 'sm', 'bp', 'wi', 'tz',
          'ei', 'ee', 'alt', 'sid', 'sdt', 'edt', 'rtb', 'tth', 'dth', 'rows', 'qcth', 'dtf1', 'dtf2', 'dtf3')
var.e.list = c('lr', 'args', 'std.dtf', flags, 'u.loc', 'ee.loc', 'start.wd')
package.list = c('readr', 'rlist', 'doParallel', 'hashmap', 'EnvStats', 'RcppParallel', 'LambertW')
function.e.list = c('store_data', 'convert_data', 'create_duration_data', 'convert_units', 'check_tz',
                    'trim_data', 'break_storms', 'cum_to_inc', 'identify_storms', 'evaluate_connectivity',
                    'int_30m', 'time_bounds', 'start_of_year', 'end_of_year', 'check_quality', 'normalize',
                    'fill_data', 'process_precip_data', 'process_alt_data', 'dew_point_temperature',
                    'process_daily_data', 'use_alt_data', 'calculate_erosion_indices', 'graph_data',
                    'export_data', 'generate_header_data', 'generate_export_data', 'create_cli_file')
export.list = c(var.e.list, function.e.list)


# Optional license prompt.
# prompt_license_agreement()

# Run the program.
main()


# Troubleshooting.
#view_data(data)  # Move this line anywhere in the 'main' function to view the primary data structure.
#options(warn = 2)
#traceback()
