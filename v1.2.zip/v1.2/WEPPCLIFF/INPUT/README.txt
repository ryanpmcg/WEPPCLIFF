Author: Ryan McGehee
Purpose: Describe contents of the folder 'INPUT'


Content:

ex_1.csv				A sample WEPPCLIFF input file which contains:
						--manually quality checked data
						--incremental precipitation data
						--metric units
						--alternative data (for calculating dew point temp)
ex_1.xlsx				The Excel file used to quality check ex_1.csv with:
						--plots for each variable
						--statistical summaries for each variable
ex_1_cp.csv				A WEPPCLIFF input file (ex_1.csv with cumulative precipitation)
ex_1_eu.csv				A WEPPCLIFF input file (ex_1_cp.csv with english units) (except for SO_RAD)
ex_1_nqc.csv				A WEPPCLIFF input file (ex_1_eu.csv without quality checking)
README.txt				This document
