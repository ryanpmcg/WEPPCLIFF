Author: Ryan McGehee
Purpose: Describe contents of the folder 'WEPPCLIFF'


Content:

EXPORT					Directory for WEPPCLIFF export files (WEPPCLIFF writes here by default)
INPUT					Directory for WEPPCLIFF input files (WEPPCLIFF reads here by default)
LIBRARY					The default dependency library for WEPPCLIFF
OUTPUT					Directory for WEPPCLIFF output files (WEPPCLIFF writes here by default)
README.txt				This document
WEPPCLIFF.R				The WEPPCLIFF source code
